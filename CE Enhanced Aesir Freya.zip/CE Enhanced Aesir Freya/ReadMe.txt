Hello,

This is the readme for the source files for the Aesir Freya mod for Conan Exiles, Enhanced version.

DESCRIPTION OF CONTENTS

Contained within are the modded race template data table for Freya and Angvarr, a small spawn table and accompanying control table for implementing Angvarr's appearance, the ModController used to perform the relevant table mergers, and three old appearance presets (Types 1 - 3) for Freya I tinkered with over the course of the mod's creation. The cover image is also provided, which you can choose to use if you wish.

INSTALLATION

To add the mod into your DevKit, copy the 'AesirFreya' folder into the mod directory. From the main DevKit folder, the path will very likely be:

\CEUE5Devkit\UE4\Content\Mods

The mod should only need to be re-cooked (rebuilt) in the DevKit to become functional once again, unless Inflexion, Funcom, or whoever else decide to do some major renovations.

MISCELLANEOUS

If you're interested in testing the mod in advance of publishing or simply for your own use, you can copy the cooked pak file to the Mods folder in your game files and then enable in the main menu.

The pak file uses the name of the AesirFreya folder in the DevKit and not the mod name in the DevKit's Info Panel. To change the name of the pak (if you want), you can copy the contents of the folder to one with the new name, though you'd have to fix broken references in the ModController's Data Table Operations section.

CONCLUSION

Hopefully that covers the basics, I look forward to seeing your version (but only if she's not borked)! If you decide to re-upload, let me know and I'll provide a link to your mod page.

Thanks for reading,

Dread Swoop
